<?php

return [
    'key' => env('ENCRYPTION_KEY', 'QKNKpSehBqTEi0VrRVJz8CH/IZuSkDtKB729T4s0uqg='),
    'iv' => env('ENCRYPTION_IV', 'JzqKYs0XgQlJdaDeLTtq+g=='),
];
