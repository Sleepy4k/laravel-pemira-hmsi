<?php

return [

    'regards' => 'Salam Hormat,',
    'footer' => 'Jika Anda mengalami masalah saat mengklik tombol :actionText, salin dan tempel URL di bawah ini ke peramban web Anda: ',

];
