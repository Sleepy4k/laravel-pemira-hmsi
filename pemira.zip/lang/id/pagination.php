<?php

return [

    /*
    |------------------------------------------------- -------------------------
    | Baris Bahasa Pagination
    |------------------------------------------------- -------------------------
    |
    | Baris bahasa berikut digunakan oleh perpustakaan paginator untuk membangun
    | link pagination sederhana. Anda bebas mengubahnya menjadi apa saja
    | Anda ingin menyesuaikan tampilan agar lebih cocok dengan aplikasi Anda.
    |
    */

    'previous' => '&laquo; Sebelumnya',
    'next' => 'Selanjutnya &raquo;',

];
