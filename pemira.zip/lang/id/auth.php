<?php

return [

    /*
    |------------------------------------------------- -------------------------
    | Baris Bahasa Otentikasi
    |------------------------------------------------- -------------------------
    |
    | Baris bahasa berikut digunakan selama otentikasi untuk berbagai
    | pesan yang perlu kita tampilkan kepada pengguna. Anda bebas untuk memodifikasi
    | baris bahasa ini sesuai dengan kebutuhan aplikasi Anda.
    |
    */

    'failed' => 'Kredensial ini tidak cocok dengan catatan kami.',
    'password' => 'Password yang diberikan salah.',
    'throttle' => 'Terlalu banyak upaya login. Silakan coba lagi dalam :seconds detik.',

];
