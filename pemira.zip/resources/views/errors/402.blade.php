<x-layout.error
    :status="402"
    title="Payment Required"
    message="Payment is required to access this resource."
/>
