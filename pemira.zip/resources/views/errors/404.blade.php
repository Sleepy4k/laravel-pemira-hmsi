<x-layout.error
    :status="404"
    title="Page Not Found"
    message="The page you are looking for could not be found."
/>
