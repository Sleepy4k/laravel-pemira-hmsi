<x-layout.error
    :status="401"
    title="Unauthorized Access"
    message="You do not have the necessary permissions to access this page."
/>
