<x-layout.error
    :status="503"
    title="Service Unavailable"
    message="The server is currently unable to handle the request due to maintenance or overload."
/>
