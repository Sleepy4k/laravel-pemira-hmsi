<x-layout.error
    :status="403"
    title="Forbidden"
    message="You do not have permission to access this resource."
/>
