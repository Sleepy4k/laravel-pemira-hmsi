<x-layout.error
    :status="500"
    title="Internal Server Error"
    message="An unexpected error occurred on the server, please try again later."
/>
