<x-layout.error
    :status="429"
    title="Too Many Requests"
    message="You have sent too many requests in a given amount of time. Please try again later."
/>
