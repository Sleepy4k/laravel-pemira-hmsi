<x-layout.error
    :status="419"
    title="Page Expired"
    message="The page has expired due to inactivity. Please refresh and try again."
/>
