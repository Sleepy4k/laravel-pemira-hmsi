<div id="{{ $id }}"
    class="fixed top-0 right-0 h-full w-96 bg-white shadow-2xl transform translate-x-full transition-transform duration-300 ease-in-out z-50 overflow-y-auto">

    {{ $slot }}
</div>
