<?php if (isset($component)) { $__componentOriginal73ed4a83482684e638654fd752f86427 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal73ed4a83482684e638654fd752f86427 = $attributes; } ?>
<?php $component = App\View\Components\Layout\Landing::resolve(['title' => 'Timeline '.e(date('Y')).''] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('layout.landing'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\Layout\Landing::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <?php if (! $__env->hasRenderedOnce('ce8244e1-2109-487a-a0ed-30f399f1950d')): $__env->markAsRenderedOnce('ce8244e1-2109-487a-a0ed-30f399f1950d');
$__env->startPush('vites'); ?>
        <?php echo app('Illuminate\Foundation\Vite')(['resources/js/lib/boxicons.js', 'resources/css/addon/timeline.css', 'resources/js/addon/timeline-landing-page.js']); ?>
    <?php $__env->stopPush(); endif; ?>

    <header data-current-date="<?php echo e($currentDate); ?>"></header>

    <section class="timeline-section">
        <div class="timeline-container">
            <h2 class="timeline-header">Timeline PEMIRA 2025</h2>
            <p class="timeline-subtitle">Ikuti setiap tahapan penting dalam perjalanan demokrasi kita</p>

            <div class="timeline">
                <?php $__currentLoopData = $timelines; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $timeline): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="timeline-item" data-start="<?php echo e($timeline->start_date); ?>"
                        data-end="<?php echo e($timeline->end_date); ?>">
                        <div class="timeline-dot">
                            <div class="dot-inner"></div>
                        </div>
                        <div class="timeline-content">
                            <div class="timeline-date"><?php echo e($timeline->range); ?></div>
                            <div class="timeline-badge">
                                <?php if($timeline->icon): ?>
                                    <box-icon name="<?php echo e($timeline->icon); ?>" color="#0b515c" size="xs"></box-icon>
                                <?php endif; ?>
                                <?php echo e($timeline->name); ?>

                            </div>
                            <p><?php echo e($timeline->description); ?></p>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    </section>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal73ed4a83482684e638654fd752f86427)): ?>
<?php $attributes = $__attributesOriginal73ed4a83482684e638654fd752f86427; ?>
<?php unset($__attributesOriginal73ed4a83482684e638654fd752f86427); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal73ed4a83482684e638654fd752f86427)): ?>
<?php $component = $__componentOriginal73ed4a83482684e638654fd752f86427; ?>
<?php unset($__componentOriginal73ed4a83482684e638654fd752f86427); ?>
<?php endif; ?>
<?php /**PATH D:\laravel\laravel-pemira-hmsi\resources\views/landing/timeline.blade.php ENDPATH**/ ?>