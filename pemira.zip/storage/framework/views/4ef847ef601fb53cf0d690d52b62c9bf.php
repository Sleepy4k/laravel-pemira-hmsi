<div id="<?php echo e($id); ?>"
    class="fixed top-0 right-0 h-full w-96 bg-white shadow-2xl transform translate-x-full transition-transform duration-300 ease-in-out z-50 overflow-y-auto">

    <?php echo e($slot); ?>

</div>
<?php /**PATH D:\laravel\laravel-pemira-hmsi\resources\views/components/canvas/wrapper.blade.php ENDPATH**/ ?>