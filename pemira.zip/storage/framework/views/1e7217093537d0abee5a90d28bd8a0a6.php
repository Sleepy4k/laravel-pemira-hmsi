<?php if (isset($component)) { $__componentOriginal3f85bed92228172e5e5ea6432b25d994 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal3f85bed92228172e5e5ea6432b25d994 = $attributes; } ?>
<?php $component = App\View\Components\Layout\Dashboard::resolve(['title' => 'Settings'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('layout.dashboard'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\Layout\Dashboard::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <?php if (! $__env->hasRenderedOnce('6b30f41f-d844-48dd-b22a-8858062b5aac')): $__env->markAsRenderedOnce('6b30f41f-d844-48dd-b22a-8858062b5aac');
$__env->startPush('vites'); ?>
        <?php echo app('Illuminate\Foundation\Vite')(['resources/js/addon/application-page.js']); ?>
    <?php $__env->stopPush(); endif; ?>

    <header data-maintenance-url="<?php echo e(route('dashboard.settings.store')); ?>" data-success="<?php echo e(session('success', '')); ?>"
        data-error="<?php echo e(session('error', '')); ?>"></header>

    <div class="mb-8 flex items-center justify-between">
        <h1 class="text-3xl font-bold text-neutral-900">
            Settings
        </h1>
        <button id="maintenance-btn" type="button" data-target="#maintenance-mode"
            class="inline-flex items-center gap-2 bg-primary-600 text-white px-4 py-2 rounded-lg font-medium hover:bg-primary-700 transition-colors cursor-pointer">
            <?php if($isMaintenanceMode): ?>
                Disable Maintenance Mode
            <?php else: ?>
                Enable Maintenance Mode
            <?php endif; ?>
        </button>
    </div>

    <div class="mb-6 border-b border-gray-200">
        <nav class="-mb-px flex space-x-8" aria-label="Tabs">
            <?php $__currentLoopData = $settingsTabs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tabKey => $tabLabel): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <a href="<?php echo e(route('dashboard.settings.index', ['tab' => $tabKey])); ?>"
                    class="whitespace-nowrap py-4 px-1 border-b-2 font-medium text-sm <?php echo e($activeTab === $tabKey ? 'border-primary-500 text-primary-600' : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'); ?>">
                    <?php echo e($tabLabel); ?>

                </a>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </nav>
    </div>

    <div id="general-settings" style="<?php echo e($activeTab === 'app' ? '' : 'display: none;'); ?>">
        <div class="p-6 bg-white rounded-xl shadow-sm">
            <h2 class="font-semibold text-gray-900 mb-4">App Settings</h2>
            <form method="POST"
                action="<?php echo e(route('dashboard.settings.update', ['tab' => 'app', 'setting' => $types['app']])); ?>"
                enctype="multipart/form-data">
                <?php echo csrf_field(); ?>
                <?php echo method_field('PUT'); ?>

                <div class="mb-4">
                    <label for="app_name" class="block text-sm font-medium text-gray-700">Application Name</label>
                    <input type="text" name="app_name" id="app_name"
                        value="<?php echo e(old('app_name', $settings['app_name'] ?? '')); ?>"
                        class="mt-1 block w-full border border-gray-300 rounded-md shadow-sm p-2 focus:ring-primary-500 focus:border-primary-500 sm:text-sm">
                </div>

                <div class="mb-4">
                    <label for="app_description" class="block text-sm font-medium text-gray-700">Application
                        Description</label>
                    <textarea name="app_description" id="app_description" rows="3"
                        class="mt-1 block w-full border border-gray-300 rounded-md shadow-sm p-2 focus:ring-primary-500 focus:border-primary-500 sm:text-sm"><?php echo e(old('app_description', $settings['app_description'] ?? '')); ?></textarea>
                </div>

                <div class="mb-4 flex flex-col md:flex-row md:space-x-6">
                    <div class="md:w-1/2">
                        <label for="app_logo" class="block text-sm font-medium text-gray-700">Application Logo</label>
                        <input type="file" name="app_logo" id="app_logo"
                            value="<?php echo e(old('app_logo', $settings['app_logo'] ?? '')); ?>" accept="image/*"
                            class="mt-1 block w-full border border-gray-300 rounded-md shadow-sm p-2 focus:ring-primary-500 focus:border-primary-500 sm:text-sm">

                        <img id="app_logo_preview" src="<?php echo e(old('app_logo', $settings['app_logo'] ?? '')); ?>"
                            alt="App Logo Preview" class="mt-2 max-h-20">
                    </div>

                    <div class="md:w-1/2 mt-4 md:mt-0">
                        <label for="app_favicon" class="block text-sm font-medium text-gray-700">Application
                            Favicon</label>
                        <input type="file" name="app_favicon" id="app_favicon"
                            value="<?php echo e(old('app_favicon', $settings['app_favicon'] ?? '')); ?>" accept="image/*"
                            class="mt-1 block w-full border border-gray-300 rounded-md shadow-sm p-2 focus:ring-primary-500 focus:border-primary-500 sm:text-sm">

                        <img id="app_favicon_preview" src="<?php echo e(old('app_favicon', $settings['app_favicon'] ?? '')); ?>"
                            alt="App Favicon Preview" class="mt-2 max-h-20">
                    </div>
                </div>

                <div class="mt-2 flex justify-end">
                    <button type="submit"
                        class="inline-flex items-center gap-2 bg-primary-600 text-white px-4 py-2 rounded-lg font-medium hover:bg-primary-700 transition-colors cursor-pointer">
                        Save Settings
                    </button>
                </div>
            </form>
        </div>
    </div>

    <div id="seo-settings" style="<?php echo e($activeTab === 'seo' ? '' : 'display: none;'); ?>">
        <div class="p-6 bg-white rounded-xl shadow-sm">
            <h2 class="font-semibold text-gray-900 mb-4">SEO Settings</h2>
            <form method="POST"
                action="<?php echo e(route('dashboard.settings.update', ['tab' => 'seo', 'setting' => $types['seo']])); ?>">
                <?php echo csrf_field(); ?>
                <?php echo method_field('PUT'); ?>

                <div class="mb-4">
                    <label for="seo_author" class="block text-sm font-medium text-gray-700">SEO Author</label>
                    <input type="text" name="seo_author" id="seo_author"
                        value="<?php echo e(old('seo_author', $settings['seo_author'] ?? '')); ?>"
                        class="mt-1 block w-full border border-gray-300 rounded-md shadow-sm p-2 focus:ring-primary-500 focus:border-primary-500 sm:text-sm">
                </div>

                <div class="mb-4">
                    <label for="seo_keywords" class="block text-sm font-medium text-gray-700">SEO Keywords (comma
                        separated)</label>
                    <input type="text" name="seo_keywords" id="seo_keywords"
                        value="<?php echo e(old('seo_keywords', $settings['seo_keywords'] ?? '')); ?>"
                        class="mt-1 block w-full border border-gray-300 rounded-md shadow-sm p-2 focus:ring-primary-500 focus:border-primary-500 sm:text-sm">
                </div>

                <div class="mb-4">
                    <label for="seo_description" class="block text-sm font-medium text-gray-700">SEO Description</label>
                    <textarea name="seo_description" id="seo_description" rows="3"
                        class="mt-1 block w-full border border-gray-300 rounded-md shadow-sm p-2 focus:ring-primary-500 focus:border-primary-500 sm:text-sm"><?php echo e(old('seo_description', $settings['seo_description'] ?? '')); ?></textarea>
                </div>

                <div class="mb-4 flex flex-col md:flex-row md:space-x-6">
                    <div class="md:w-1/2">
                        <label for="seo_image_width" class="block text-sm font-medium text-gray-700">SEO Image Width
                            (px)</label>
                        <input type="number" name="seo_image_width" id="seo_image_width"
                            value="<?php echo e(old('seo_image_width', $settings['seo_image_width'] ?? '')); ?>"
                            class="mt-1 block w-full border border-gray-300 rounded-md shadow-sm p-2 focus:ring-primary-500 focus:border-primary-500 sm:text-sm">
                    </div>

                    <div class="md:w-1/2 mt-4 md:mt-0">
                        <label for="seo_image_height" class="block text-sm font-medium text-gray-700">SEO Image Height
                            (px)</label>
                        <input type="number" name="seo_image_height" id="seo_image_height"
                            value="<?php echo e(old('seo_image_height', $settings['seo_image_height'] ?? '')); ?>"
                            class="mt-1 block w-full border border-gray-300 rounded-md shadow-sm p-2 focus:ring-primary-500 focus:border-primary-500 sm:text-sm">
                    </div>
                </div>

                <div class="mt-2 flex justify-end">
                    <button type="submit"
                        class="inline-flex items-center gap-2 bg-primary-600 text-white px-4 py-2 rounded-lg font-medium hover:bg-primary-700 transition-colors cursor-pointer">
                        Save Settings
                    </button>
                </div>
            </form>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal3f85bed92228172e5e5ea6432b25d994)): ?>
<?php $attributes = $__attributesOriginal3f85bed92228172e5e5ea6432b25d994; ?>
<?php unset($__attributesOriginal3f85bed92228172e5e5ea6432b25d994); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal3f85bed92228172e5e5ea6432b25d994)): ?>
<?php $component = $__componentOriginal3f85bed92228172e5e5ea6432b25d994; ?>
<?php unset($__componentOriginal3f85bed92228172e5e5ea6432b25d994); ?>
<?php endif; ?>
<?php /**PATH D:\laravel\laravel-pemira-hmsi\resources\views/dashboard/settings/app.blade.php ENDPATH**/ ?>