<?php if (isset($component)) { $__componentOriginalc957a716c76f75ab493e3d14c147c8dd = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalc957a716c76f75ab493e3d14c147c8dd = $attributes; } ?>
<?php $component = App\View\Components\Layout\Error::resolve(['status' => 404,'title' => 'Page Not Found','message' => 'The page you are looking for could not be found.'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('layout.error'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\Layout\Error::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalc957a716c76f75ab493e3d14c147c8dd)): ?>
<?php $attributes = $__attributesOriginalc957a716c76f75ab493e3d14c147c8dd; ?>
<?php unset($__attributesOriginalc957a716c76f75ab493e3d14c147c8dd); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc957a716c76f75ab493e3d14c147c8dd)): ?>
<?php $component = $__componentOriginalc957a716c76f75ab493e3d14c147c8dd; ?>
<?php unset($__componentOriginalc957a716c76f75ab493e3d14c147c8dd); ?>
<?php endif; ?>
<?php /**PATH D:\laravel\laravel-pemira-hmsi\resources\views/errors/404.blade.php ENDPATH**/ ?>