<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
    <head>
        <meta charset="UTF-8">
        <meta name="title" content="<?php echo e($appSettings['app_name']); ?> - <?php echo e($title); ?>">
        <meta name="description" content="<?php echo e($appSettings['app_description']); ?>">
        <meta name="author" content="<?php echo e($appSettings['seo_author']); ?>">
        <meta name="coverage" content="Worldwide">
        <meta name="distribution" content="Global">
        <meta name="robots" content="index, follow">
        <meta name="keywords" content="<?php echo e($appSettings['seo_keywords']); ?>">
        <meta name="viewport" content="width=device-width, initial-scale=1">

        <link rel="canonical" href="<?php echo e(config('app.url')); ?>">

        <link rel="icon" href="<?php echo e($appSettings['app_favicon']); ?>" />
        <link rel="shortcut icon" href="<?php echo e($appSettings['app_favicon']); ?>" />
        <link rel="apple-touch-icon" href="<?php echo e($appSettings['app_favicon']); ?>" />
        <link rel="apple-touch-icon-precomposed" href="<?php echo e($appSettings['app_favicon']); ?>" />

        <title><?php echo e($appSettings['app_name']); ?> - <?php echo e($title); ?></title>

        <?php echo \Spatie\Csp\CspMetaTag::create() ?>

        <meta property="csrf-token" content="<?php echo e(csrf_token()); ?>">
        <meta property="csp-nonce" content="<?php echo e(app('csp-nonce')); ?>">

        <meta property="og:locale" content="<?php echo e(app()->getLocale()); ?>">
        <meta property="og:url" content="<?php echo e(url()->current()); ?>">
        <meta property="og:type" content="website">
        <meta property="og:site_name" content="<?php echo e($appSettings['app_name']); ?>">
        <meta property="og:title" content="<?php echo e($appSettings['app_name']); ?> - <?php echo e($title); ?>">
        <meta property="og:description" content="<?php echo e($appSettings['app_description']); ?>">
        <meta property="og:image" content="<?php echo e($appSettings['app_logo']); ?>">
        <meta property="og:image:width" content="<?php echo e($appSettings['seo_image_width']); ?>" />
        <meta property="og:image:height" content="<?php echo e($appSettings['seo_image_height']); ?>" />
        <meta property="og:image:type" content="image/png">
        <meta property="og:image:alt" content="<?php echo e($appSettings['app_name']); ?> - <?php echo e($title); ?>">

        <meta property="twitter:card" content="summary_large_image">
        <meta property="twitter:domain" content="<?php echo e(url()->current()); ?>">
        <meta property="twitter:url" content="<?php echo e(url()->current()); ?>">
        <meta property="twitter:locale" content="<?php echo e(app()->getLocale()); ?>">
        <meta property="twitter:title" content="<?php echo e($appSettings['app_name']); ?> - <?php echo e($title); ?>">
        <meta property="twitter:description" content="<?php echo e($appSettings['app_description']); ?>">
        <meta property="twitter:image" content="<?php echo e($appSettings['app_logo']); ?>">
        <meta property="twitter:image:width" content="<?php echo e($appSettings['seo_image_width']); ?>" />
        <meta property="twitter:image:height" content="<?php echo e($appSettings['seo_image_height']); ?>" />
        <meta property="twitter:image:type" content="image/png">
        <meta property="twitter:image:alt" content="<?php echo e($appSettings['app_name']); ?> - <?php echo e($title); ?>">

        <?php echo app('Illuminate\Foundation\Vite')(['resources/css/app.css', 'resources/js/app.js', 'resources/js/lib/boxicons.js', 'resources/js/addon/layout-dashboard.js']); ?>

        <?php echo $__env->yieldPushContent('vites'); ?>
    </head>
    <body>
        <div class="flex h-screen bg-neutral-100 font-sans">
            <div id="sidebar-overlay" class="fixed inset-0 bg-black/30 backdrop-blur-sm z-30 lg:hidden hidden"></div>

            <?php if (isset($component)) { $__componentOriginal329b1746a750ecc7ba22b48fb78d1fce = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal329b1746a750ecc7ba22b48fb78d1fce = $attributes; } ?>
<?php $component = App\View\Components\Dashboard\Sidebar::resolve(['appName' => $appSettings['app_name'],'appLogo' => $appSettings['app_logo']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('dashboard.sidebar'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\Dashboard\Sidebar::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal329b1746a750ecc7ba22b48fb78d1fce)): ?>
<?php $attributes = $__attributesOriginal329b1746a750ecc7ba22b48fb78d1fce; ?>
<?php unset($__attributesOriginal329b1746a750ecc7ba22b48fb78d1fce); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal329b1746a750ecc7ba22b48fb78d1fce)): ?>
<?php $component = $__componentOriginal329b1746a750ecc7ba22b48fb78d1fce; ?>
<?php unset($__componentOriginal329b1746a750ecc7ba22b48fb78d1fce); ?>
<?php endif; ?>

            <main class="flex-1 overflow-y-auto flex flex-col">
                <?php if (isset($component)) { $__componentOriginalb6ee58394908b3e15421dd3072d4a76e = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalb6ee58394908b3e15421dd3072d4a76e = $attributes; } ?>
<?php $component = App\View\Components\Dashboard\Navbar::resolve(['title' => $title] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('dashboard.navbar'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\Dashboard\Navbar::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalb6ee58394908b3e15421dd3072d4a76e)): ?>
<?php $attributes = $__attributesOriginalb6ee58394908b3e15421dd3072d4a76e; ?>
<?php unset($__attributesOriginalb6ee58394908b3e15421dd3072d4a76e); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalb6ee58394908b3e15421dd3072d4a76e)): ?>
<?php $component = $__componentOriginalb6ee58394908b3e15421dd3072d4a76e; ?>
<?php unset($__componentOriginalb6ee58394908b3e15421dd3072d4a76e); ?>
<?php endif; ?>

                <div class="flex-1 p-8 lg:p-8" id="main-content" style="display: none;">
                    <?php echo e($slot); ?>

                </div>

                <div id="offcanvas-backdrop"
                    class="fixed inset-0 backdrop-blur-xs bg-white/30 bg-opacity-50 z-40 hidden transition-opacity duration-300">
                </div>

                <div class="flex-1 p-8 lg:p-8" id="main-loader">
                    <div class="flex flex-col items-center justify-center h-full">
                        <div class="loader ease-linear rounded-full border-8 border-t-8 border-gray-200 h-16 w-16 mb-4"></div>
                        <h2 class="text-center text-xl font-semibold text-neutral-700">Loading...</h2>
                    </div>
                </div>

                <?php if (isset($component)) { $__componentOriginal242504bb94b9c159c150822b98968500 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal242504bb94b9c159c150822b98968500 = $attributes; } ?>
<?php $component = App\View\Components\Dashboard\Footer::resolve(['appName' => $appSettings['app_name']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('dashboard.footer'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\Dashboard\Footer::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal242504bb94b9c159c150822b98968500)): ?>
<?php $attributes = $__attributesOriginal242504bb94b9c159c150822b98968500; ?>
<?php unset($__attributesOriginal242504bb94b9c159c150822b98968500); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal242504bb94b9c159c150822b98968500)): ?>
<?php $component = $__componentOriginal242504bb94b9c159c150822b98968500; ?>
<?php unset($__componentOriginal242504bb94b9c159c150822b98968500); ?>
<?php endif; ?>
            </main>

            <form id="logout-form" data-action="<?php echo e(route('logout')); ?>" data-redirect="<?php echo e(route('landing')); ?>"
                class="hidden"></form>
        </div>

        <?php if (isset($component)) { $__componentOriginalaf4532e536ab6e4dc2caf25dfd2e7a59 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalaf4532e536ab6e4dc2caf25dfd2e7a59 = $attributes; } ?>
<?php $component = App\View\Components\Utils\Noscript::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('utils.noscript'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\Utils\Noscript::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalaf4532e536ab6e4dc2caf25dfd2e7a59)): ?>
<?php $attributes = $__attributesOriginalaf4532e536ab6e4dc2caf25dfd2e7a59; ?>
<?php unset($__attributesOriginalaf4532e536ab6e4dc2caf25dfd2e7a59); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalaf4532e536ab6e4dc2caf25dfd2e7a59)): ?>
<?php $component = $__componentOriginalaf4532e536ab6e4dc2caf25dfd2e7a59; ?>
<?php unset($__componentOriginalaf4532e536ab6e4dc2caf25dfd2e7a59); ?>
<?php endif; ?>

        <?php echo $__env->yieldPushContent('scripts'); ?>
    </body>
</html>
<?php /**PATH D:\laravel\laravel-pemira-hmsi\resources\views/components/layout/dashboard.blade.php ENDPATH**/ ?>