<?php if (isset($component)) { $__componentOriginal3f85bed92228172e5e5ea6432b25d994 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal3f85bed92228172e5e5ea6432b25d994 = $attributes; } ?>
<?php $component = App\View\Components\Layout\Dashboard::resolve(['title' => 'Dashboard'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('layout.dashboard'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\Layout\Dashboard::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <?php if (! $__env->hasRenderedOnce('17df70f6-8798-4e42-a76e-82251df926b1')): $__env->markAsRenderedOnce('17df70f6-8798-4e42-a76e-82251df926b1');
$__env->startPush('vites'); ?>
        <?php echo app('Illuminate\Foundation\Vite')(['resources/js/lib/apexchart.js', 'resources/js/addon/home-page.js']); ?>
    <?php $__env->stopPush(); endif; ?>

    <div class="mb-8">
        <h1 class="text-3xl font-bold text-neutral-900 mb-2">
            Welcome back, <?php echo e(auth('web')->user()->name ?? 'Admin'); ?>!
        </h1>
        <p class="text-neutral-600">
            Here's an overview of the voting statistics. Ensure to monitor the voter turnout and session details
            regularly.
        </p>
    </div>

    <div class="flex flex-col gap-6 mb-8">
        <div class="flex flex-col md:flex-row gap-6">
            <div
                class="flex-1 bg-white rounded-xl shadow-sm border border-neutral-200 p-6 hover:shadow-md transition-shadow">
                <div class="flex items-center justify-between">
                    <div>
                        <p class="text-sm font-medium text-neutral-500 mb-1">Total Voters</p>
                        <p class="text-3xl font-bold text-neutral-900"><?php echo e($totalVoters ?? 0); ?></p>
                    </div>
                    <div class="bg-blue-100 p-3 rounded-lg">
                        <svg class="w-6 h-6 text-blue-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                                d="M17 20h5v-2a3 3 0 00-5.356-1.857M17 20H7m10 0v-2c0-.656-.126-1.283-.356-1.857M7 20H2v-2a3 3 0 015.356-1.857M7 20v-2c0-.656.126-1.283.356-1.857m0 0a5.002 5.002 0 019.288 0M15 7a3 3 0 11-6 0 3 3 0 016 0zm6 3a2 2 0 11-4 0 2 2 0 014 0zM7 10a2 2 0 11-4 0 2 2 0 014 0z">
                            </path>
                        </svg>
                    </div>
                </div>
            </div>
            <div
                class="flex-1 bg-white rounded-xl shadow-sm border border-neutral-200 p-6 hover:shadow-md transition-shadow">
                <div class="flex items-center justify-between">
                    <div>
                        <p class="text-sm font-medium text-neutral-500 mb-1">Has Voted</p>
                        <p class="text-3xl font-bold text-green-600"><?php echo e($hasVoted ?? 0); ?></p>
                    </div>
                    <div class="bg-green-100 p-3 rounded-lg">
                        <svg class="w-6 h-6 text-green-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                                d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z"></path>
                        </svg>
                    </div>
                </div>
            </div>
            <div
                class="flex-1 bg-white rounded-xl shadow-sm border border-neutral-200 p-6 hover:shadow-md transition-shadow">
                <div class="flex items-center justify-between">
                    <div>
                        <p class="text-sm font-medium text-neutral-500 mb-1">Not Voted</p>
                        <p class="text-3xl font-bold text-red-600"><?php echo e($notVoted ?? 0); ?></p>
                    </div>
                    <div class="bg-red-100 p-3 rounded-lg">
                        <svg class="w-6 h-6 text-red-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                                d="M12 8v4m0 4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z"></path>
                        </svg>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="grid grid-cols-1 lg:grid-cols-4 gap-6">
        <div class="lg:col-span-3 bg-white rounded-xl shadow-sm border border-neutral-200 p-6">
            <div id="barChart" data-chart="<?php echo e(json_encode($votesPerBatch)); ?>" data-categories="<?php echo e(json_encode($batches->pluck('name'))); ?>"></div>
        </div>
        <div class="bg-white rounded-xl shadow-sm border border-neutral-200 p-6">
            <div id="pieChart" data-chart="<?php echo e(json_encode($votingStatus)); ?>"></div>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal3f85bed92228172e5e5ea6432b25d994)): ?>
<?php $attributes = $__attributesOriginal3f85bed92228172e5e5ea6432b25d994; ?>
<?php unset($__attributesOriginal3f85bed92228172e5e5ea6432b25d994); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal3f85bed92228172e5e5ea6432b25d994)): ?>
<?php $component = $__componentOriginal3f85bed92228172e5e5ea6432b25d994; ?>
<?php unset($__componentOriginal3f85bed92228172e5e5ea6432b25d994); ?>
<?php endif; ?>
<?php /**PATH D:\laravel\laravel-pemira-hmsi\resources\views/dashboard/home.blade.php ENDPATH**/ ?>