<nav>
    <div class="logo">
        <div class="logos-container">
            <div class="logo-item logo-1">
                <img src="<?php echo e(asset('images/si.png')); ?>" alt="HIMASI Logo" loading="lazy">
            </div>
            <div class="logo-item logo-2">
                <img src="<?php echo e($logo); ?>" alt="PEMIRA Logo" loading="lazy">
            </div>
        </div>
    </div>

    <ul class="nav-links">
        <li><a href="<?php echo e(route('landing')); ?>" class="<?php echo e(request()->routeIs('landing') ? 'active' : ''); ?>">Beranda</a></li>
        <li><a href="<?php echo e(route('about')); ?>" class="<?php echo e(request()->routeIs('about') ? 'active' : ''); ?>">Tentang</a></li>
        <li><a href="<?php echo e(route('timeline')); ?>" class="<?php echo e(request()->routeIs('timeline') ? 'active' : ''); ?>">Timeline</a></li>
        <li><a href="<?php echo e(route('candidates')); ?>" class="<?php echo e(request()->routeIs('candidates') ? 'active' : ''); ?>">Kandidat</a></li>
    </ul>

    <div class="nav-buttons">
        <?php if(auth('web')->check()): ?>
            <button class="btn-login" id="dashboard-button" data-redirect="<?php echo e(route('dashboard')); ?>">Dashboard</button>
        <?php else: ?>
            <button class="btn-login" id="login-button" data-redirect="<?php echo e(route('signin')); ?>">Masuk</button>
        <?php endif; ?>
        <button class="btn-vote" id="vote-button" data-redirect="<?php echo e(route('vote.index')); ?>">Mulai Voting</button>
    </div>
</nav>
<?php /**PATH D:\laravel\laravel-pemira-hmsi\resources\views/components/landing/navbar.blade.php ENDPATH**/ ?>