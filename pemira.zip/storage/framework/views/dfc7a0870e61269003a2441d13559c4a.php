<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
    <head>
        <meta charset="UTF-8">
        <meta name="title" content="<?php echo e($appSettings['app_name']); ?> - <?php echo e($title); ?>">
        <meta name="description" content="<?php echo e($appSettings['app_description']); ?>">
        <meta name="author" content="<?php echo e($appSettings['seo_author']); ?>">
        <meta name="coverage" content="Worldwide">
        <meta name="distribution" content="Global">
        <meta name="robots" content="index, follow">
        <meta name="keywords" content="<?php echo e($appSettings['seo_keywords']); ?>">
        <meta name="viewport" content="width=device-width, initial-scale=1">

        <link rel="canonical" href="<?php echo e(config('app.url')); ?>">

        <link rel="icon" href="<?php echo e($appSettings['app_favicon']); ?>" />
        <link rel="shortcut icon" href="<?php echo e($appSettings['app_favicon']); ?>" />
        <link rel="apple-touch-icon" href="<?php echo e($appSettings['app_favicon']); ?>" />
        <link rel="apple-touch-icon-precomposed" href="<?php echo e($appSettings['app_favicon']); ?>" />

        <title><?php echo e($appSettings['app_name']); ?> - <?php echo e($title); ?></title>

        <?php echo \Spatie\Csp\CspMetaTag::create() ?>

        <meta property="csp-nonce" content="<?php echo e(app('csp-nonce')); ?>">

        <meta property="og:locale" content="<?php echo e(app()->getLocale()); ?>">
        <meta property="og:url" content="<?php echo e(url()->current()); ?>">
        <meta property="og:type" content="website">
        <meta property="og:site_name" content="<?php echo e($appSettings['app_name']); ?>">
        <meta property="og:title" content="<?php echo e($appSettings['app_name']); ?> - <?php echo e($title); ?>">
        <meta property="og:description" content="<?php echo e($appSettings['app_description']); ?>">
        <meta property="og:image" content="<?php echo e($appSettings['app_logo']); ?>">
        <meta property="og:image:width" content="<?php echo e($appSettings['seo_image_width']); ?>" />
        <meta property="og:image:height" content="<?php echo e($appSettings['seo_image_height']); ?>" />
        <meta property="og:image:type" content="image/png">
        <meta property="og:image:alt" content="<?php echo e($appSettings['app_name']); ?> - <?php echo e($title); ?>">

        <meta property="twitter:card" content="summary_large_image">
        <meta property="twitter:domain" content="<?php echo e(url()->current()); ?>">
        <meta property="twitter:url" content="<?php echo e(url()->current()); ?>">
        <meta property="twitter:locale" content="<?php echo e(app()->getLocale()); ?>">
        <meta property="twitter:title" content="<?php echo e($appSettings['app_name']); ?> - <?php echo e($title); ?>">
        <meta property="twitter:description" content="<?php echo e($appSettings['app_description']); ?>">
        <meta property="twitter:image" content="<?php echo e($appSettings['app_logo']); ?>">
        <meta property="twitter:image:width" content="<?php echo e($appSettings['seo_image_width']); ?>" />
        <meta property="twitter:image:height" content="<?php echo e($appSettings['seo_image_height']); ?>" />
        <meta property="twitter:image:type" content="image/png">
        <meta property="twitter:image:alt" content="<?php echo e($appSettings['app_name']); ?> - <?php echo e($title); ?>">

        <?php echo app('Illuminate\Foundation\Vite')(['resources/css/addon/landing.css', 'resources/js/addon/layout-landing.js']); ?>

        <?php echo $__env->yieldPushContent('vites'); ?>
    </head>
    <body>
        <div class="refresh-animation">
            <div class="refresh-logo">
                <div class="logo-item logo-2">
                    <img src="<?php echo e($appSettings['app_logo']); ?>" alt="HIMASI Logo" loading="lazy">
                </div>
            </div>
        </div>

        <div class="pattern-overlay"></div>
        <div class="floating-shapes">
            <div class="shape shape1"></div>
            <div class="shape shape2"></div>
            <div class="shape shape3"></div>
        </div>

        <?php if (isset($component)) { $__componentOriginal6a165c3c869aa0bc21be8e4f600485dc = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal6a165c3c869aa0bc21be8e4f600485dc = $attributes; } ?>
<?php $component = App\View\Components\Landing\Navbar::resolve(['logo' => $appSettings['app_logo']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('landing.navbar'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\Landing\Navbar::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal6a165c3c869aa0bc21be8e4f600485dc)): ?>
<?php $attributes = $__attributesOriginal6a165c3c869aa0bc21be8e4f600485dc; ?>
<?php unset($__attributesOriginal6a165c3c869aa0bc21be8e4f600485dc); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal6a165c3c869aa0bc21be8e4f600485dc)): ?>
<?php $component = $__componentOriginal6a165c3c869aa0bc21be8e4f600485dc; ?>
<?php unset($__componentOriginal6a165c3c869aa0bc21be8e4f600485dc); ?>
<?php endif; ?>

        <?php echo e($slot); ?>


        <?php if (isset($component)) { $__componentOriginal28f0abd1a60e785867b7e18cfedaa6ad = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal28f0abd1a60e785867b7e18cfedaa6ad = $attributes; } ?>
<?php $component = App\View\Components\Landing\Footer::resolve(['logo' => $appSettings['app_logo']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('landing.footer'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\Landing\Footer::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal28f0abd1a60e785867b7e18cfedaa6ad)): ?>
<?php $attributes = $__attributesOriginal28f0abd1a60e785867b7e18cfedaa6ad; ?>
<?php unset($__attributesOriginal28f0abd1a60e785867b7e18cfedaa6ad); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal28f0abd1a60e785867b7e18cfedaa6ad)): ?>
<?php $component = $__componentOriginal28f0abd1a60e785867b7e18cfedaa6ad; ?>
<?php unset($__componentOriginal28f0abd1a60e785867b7e18cfedaa6ad); ?>
<?php endif; ?>

        <?php if (isset($component)) { $__componentOriginalaf4532e536ab6e4dc2caf25dfd2e7a59 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalaf4532e536ab6e4dc2caf25dfd2e7a59 = $attributes; } ?>
<?php $component = App\View\Components\Utils\Noscript::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('utils.noscript'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\Utils\Noscript::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalaf4532e536ab6e4dc2caf25dfd2e7a59)): ?>
<?php $attributes = $__attributesOriginalaf4532e536ab6e4dc2caf25dfd2e7a59; ?>
<?php unset($__attributesOriginalaf4532e536ab6e4dc2caf25dfd2e7a59); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalaf4532e536ab6e4dc2caf25dfd2e7a59)): ?>
<?php $component = $__componentOriginalaf4532e536ab6e4dc2caf25dfd2e7a59; ?>
<?php unset($__componentOriginalaf4532e536ab6e4dc2caf25dfd2e7a59); ?>
<?php endif; ?>
    </body>
</html>
<?php /**PATH D:\laravel\laravel-pemira-hmsi\resources\views/components/layout/landing.blade.php ENDPATH**/ ?>