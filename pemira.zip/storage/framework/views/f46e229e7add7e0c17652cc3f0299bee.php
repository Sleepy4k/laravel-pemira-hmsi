<?php if (isset($component)) { $__componentOriginal3f85bed92228172e5e5ea6432b25d994 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal3f85bed92228172e5e5ea6432b25d994 = $attributes; } ?>
<?php $component = App\View\Components\Layout\Dashboard::resolve(['title' => 'Voters'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('layout.dashboard'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\Layout\Dashboard::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <?php if (! $__env->hasRenderedOnce('6dd11be6-e377-4086-9213-cd9c31010f3d')): $__env->markAsRenderedOnce('6dd11be6-e377-4086-9213-cd9c31010f3d');
$__env->startPush('vites'); ?>
        <?php echo app('Illuminate\Foundation\Vite')(['resources/css/lib/datatable.css', 'resources/js/lib/datatable.js', 'resources/js/handler/offcanvas.js', 'resources/js/addon/voter-page.js']); ?>
    <?php $__env->stopPush(); endif; ?>

    <header data-debug="<?php echo e(config('app.debug') ? 'true' : 'false'); ?>"
        data-routes='{
            "update": "<?php echo e(route('dashboard.voters.update', ':id')); ?>",
            "destroy": "<?php echo e(route('dashboard.voters.destroy', ':id')); ?>"
        }'></header>

    <div class="mb-8 flex items-center justify-between">
        <h1 class="text-3xl font-bold text-neutral-900">
            List of Voters
        </h1>
        <button id="add-new-record-btn" type="button" data-target="#add-new-record"
            class="inline-flex items-center gap-2 bg-primary-600 text-white px-4 py-2 rounded-lg font-medium hover:bg-primary-700 transition-colors cursor-pointer">
            <svg xmlns="http://www.w3.org/2000/svg" class="h-5 w-5" viewBox="0 0 20 20" fill="currentColor">
                <path fill-rule="evenodd"
                    d="M10 3a1 1 0 011 1v5h5a1 1 0 110 2h-5v5a1 1 0 11-2 0v-5H4a1 1 0 110-2h5V4a1 1 0 011-1z"
                    clip-rule="evenodd" />
            </svg>
            Voter
        </button>
    </div>

    <?php echo e($dataTable->table()); ?>


    <?php if (isset($component)) { $__componentOriginal2094e66eddc217ae20790ec50c8e5484 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal2094e66eddc217ae20790ec50c8e5484 = $attributes; } ?>
<?php $component = App\View\Components\Canvas\Wrapper::resolve(['id' => 'add-new-record'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('canvas.wrapper'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\Canvas\Wrapper::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
        <?php if (isset($component)) { $__componentOriginalbfc0bb67c76b6c391343f366360e39cc = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalbfc0bb67c76b6c391343f366360e39cc = $attributes; } ?>
<?php $component = App\View\Components\Canvas\Header::resolve(['title' => 'New Record'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('canvas.header'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\Canvas\Header::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
            <form class="space-y-4" method="POST" action="<?php echo e(route('dashboard.voters.store')); ?>"
                id="form-add-new-record">
                <div>
                    <label for="name" class="block text-sm font-semibold text-gray-700 mb-1.5">Name</label>
                    <input type="text" id="name" name="name" placeholder="Enter voter name"
                        class="w-full px-4 py-2.5 border border-gray-200 rounded-lg text-gray-700 placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all">
                </div>
                <div>
                    <label for="email" class="block text-sm font-semibold text-gray-700 mb-1.5">Email</label>
                    <input type="email" id="email" name="email" placeholder="Enter voter email"
                        class="w-full px-4 py-2.5 border border-gray-200 rounded-lg text-gray-700 placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all">
                </div>
                <div>
                    <label for="batch_id" class="block text-sm font-semibold text-gray-700 mb-1.5">Batch</label>
                    <select id="batch_id" name="batch_id"
                        class="w-full px-4 py-2.5 border border-gray-200 rounded-lg text-gray-700 placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all">
                        <option value="" disabled selected>Select a batch</option>
                        <?php $__currentLoopData = $batches; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $batch): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($batch->id); ?>"><?php echo e($batch->name); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>
            </form>
         <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalbfc0bb67c76b6c391343f366360e39cc)): ?>
<?php $attributes = $__attributesOriginalbfc0bb67c76b6c391343f366360e39cc; ?>
<?php unset($__attributesOriginalbfc0bb67c76b6c391343f366360e39cc); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalbfc0bb67c76b6c391343f366360e39cc)): ?>
<?php $component = $__componentOriginalbfc0bb67c76b6c391343f366360e39cc; ?>
<?php unset($__componentOriginalbfc0bb67c76b6c391343f366360e39cc); ?>
<?php endif; ?>
        <?php if (isset($component)) { $__componentOriginal4bf40cb3dea8912ce01b773d2a33c1e9 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal4bf40cb3dea8912ce01b773d2a33c1e9 = $attributes; } ?>
<?php $component = App\View\Components\Canvas\Footer::resolve(['isCreate' => true] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('canvas.footer'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\Canvas\Footer::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal4bf40cb3dea8912ce01b773d2a33c1e9)): ?>
<?php $attributes = $__attributesOriginal4bf40cb3dea8912ce01b773d2a33c1e9; ?>
<?php unset($__attributesOriginal4bf40cb3dea8912ce01b773d2a33c1e9); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal4bf40cb3dea8912ce01b773d2a33c1e9)): ?>
<?php $component = $__componentOriginal4bf40cb3dea8912ce01b773d2a33c1e9; ?>
<?php unset($__componentOriginal4bf40cb3dea8912ce01b773d2a33c1e9); ?>
<?php endif; ?>
     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal2094e66eddc217ae20790ec50c8e5484)): ?>
<?php $attributes = $__attributesOriginal2094e66eddc217ae20790ec50c8e5484; ?>
<?php unset($__attributesOriginal2094e66eddc217ae20790ec50c8e5484); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal2094e66eddc217ae20790ec50c8e5484)): ?>
<?php $component = $__componentOriginal2094e66eddc217ae20790ec50c8e5484; ?>
<?php unset($__componentOriginal2094e66eddc217ae20790ec50c8e5484); ?>
<?php endif; ?>

    <?php if (isset($component)) { $__componentOriginal2094e66eddc217ae20790ec50c8e5484 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal2094e66eddc217ae20790ec50c8e5484 = $attributes; } ?>
<?php $component = App\View\Components\Canvas\Wrapper::resolve(['id' => 'show-record'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('canvas.wrapper'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\Canvas\Wrapper::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
        <?php if (isset($component)) { $__componentOriginalbfc0bb67c76b6c391343f366360e39cc = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalbfc0bb67c76b6c391343f366360e39cc = $attributes; } ?>
<?php $component = App\View\Components\Canvas\Header::resolve(['title' => 'Show Record'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('canvas.header'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\Canvas\Header::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
            <div class="space-y-4">
                <div>
                    <h3 class="text-sm font-semibold text-gray-500 mb-1.5">Name</h3>
                    <p id="show-name" class="text-gray-700 text-body-lg">-</p>
                </div>
                <div>
                    <h3 class="text-sm font-semibold text-gray-500 mb-1.5">Email</h3>
                    <p id="show-email" class="text-gray-700 text-body-lg">-</p>
                </div>
                <div>
                    <h3 class="text-sm font-semibold text-gray-500 mb-1.5">Batch</h3>
                    <p id="show-batch" class="text-gray-700 text-body-lg">-</p>
                </div>
                <div>
                    <h3 class="text-sm font-semibold text-gray-500 mb-1.5">Voted At</h3>
                    <p id="show-voted-at" class="text-gray-700 text-body-lg">-</p>
                </div>
            </div>
         <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalbfc0bb67c76b6c391343f366360e39cc)): ?>
<?php $attributes = $__attributesOriginalbfc0bb67c76b6c391343f366360e39cc; ?>
<?php unset($__attributesOriginalbfc0bb67c76b6c391343f366360e39cc); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalbfc0bb67c76b6c391343f366360e39cc)): ?>
<?php $component = $__componentOriginalbfc0bb67c76b6c391343f366360e39cc; ?>
<?php unset($__componentOriginalbfc0bb67c76b6c391343f366360e39cc); ?>
<?php endif; ?>
        <?php if (isset($component)) { $__componentOriginal4bf40cb3dea8912ce01b773d2a33c1e9 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal4bf40cb3dea8912ce01b773d2a33c1e9 = $attributes; } ?>
<?php $component = App\View\Components\Canvas\Footer::resolve(['type' => 'show'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('canvas.footer'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\Canvas\Footer::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal4bf40cb3dea8912ce01b773d2a33c1e9)): ?>
<?php $attributes = $__attributesOriginal4bf40cb3dea8912ce01b773d2a33c1e9; ?>
<?php unset($__attributesOriginal4bf40cb3dea8912ce01b773d2a33c1e9); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal4bf40cb3dea8912ce01b773d2a33c1e9)): ?>
<?php $component = $__componentOriginal4bf40cb3dea8912ce01b773d2a33c1e9; ?>
<?php unset($__componentOriginal4bf40cb3dea8912ce01b773d2a33c1e9); ?>
<?php endif; ?>
     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal2094e66eddc217ae20790ec50c8e5484)): ?>
<?php $attributes = $__attributesOriginal2094e66eddc217ae20790ec50c8e5484; ?>
<?php unset($__attributesOriginal2094e66eddc217ae20790ec50c8e5484); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal2094e66eddc217ae20790ec50c8e5484)): ?>
<?php $component = $__componentOriginal2094e66eddc217ae20790ec50c8e5484; ?>
<?php unset($__componentOriginal2094e66eddc217ae20790ec50c8e5484); ?>
<?php endif; ?>

    <?php if (isset($component)) { $__componentOriginal2094e66eddc217ae20790ec50c8e5484 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal2094e66eddc217ae20790ec50c8e5484 = $attributes; } ?>
<?php $component = App\View\Components\Canvas\Wrapper::resolve(['id' => 'edit-record'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('canvas.wrapper'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\Canvas\Wrapper::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
        <?php if (isset($component)) { $__componentOriginalbfc0bb67c76b6c391343f366360e39cc = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalbfc0bb67c76b6c391343f366360e39cc = $attributes; } ?>
<?php $component = App\View\Components\Canvas\Header::resolve(['title' => 'Edit Candidate'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('canvas.header'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\Canvas\Header::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
            <form id="form-edit-record" class="space-y-4" method="PUT" action="#">
                <div>
                    <label for="edit-name" class="block text-sm font-semibold text-gray-700 mb-1.5">Name</label>
                    <input type="text" id="edit-name" name="name" placeholder="Enter voter name"
                        class="w-full px-4 py-2.5 border border-gray-200 rounded-lg text-gray-700 placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all">
                </div>
                <div>
                    <label for="edit-email" class="block text-sm font-semibold text-gray-700 mb-1.5">Email</label>
                    <input type="email" id="edit-email" name="email" placeholder="Enter voter email"
                        class="w-full px-4 py-2.5 border border-gray-200 rounded-lg text-gray-700 placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all">
                </div>
                <div>
                    <label for="edit-batch_id" class="block text-sm font-semibold text-gray-700 mb-1.5">Batch</label>
                    <select id="edit-batch_id" name="batch_id"
                        class="w-full px-4 py-2.5 border border-gray-200 rounded-lg text-gray-700 placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all">
                        <option value="" disabled selected>Select a batch</option>
                        <?php $__currentLoopData = $batches; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $batch): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($batch->id); ?>"><?php echo e($batch->name); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>
            </form>
         <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalbfc0bb67c76b6c391343f366360e39cc)): ?>
<?php $attributes = $__attributesOriginalbfc0bb67c76b6c391343f366360e39cc; ?>
<?php unset($__attributesOriginalbfc0bb67c76b6c391343f366360e39cc); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalbfc0bb67c76b6c391343f366360e39cc)): ?>
<?php $component = $__componentOriginalbfc0bb67c76b6c391343f366360e39cc; ?>
<?php unset($__componentOriginalbfc0bb67c76b6c391343f366360e39cc); ?>
<?php endif; ?>
        <?php if (isset($component)) { $__componentOriginal4bf40cb3dea8912ce01b773d2a33c1e9 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal4bf40cb3dea8912ce01b773d2a33c1e9 = $attributes; } ?>
<?php $component = App\View\Components\Canvas\Footer::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('canvas.footer'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\Canvas\Footer::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal4bf40cb3dea8912ce01b773d2a33c1e9)): ?>
<?php $attributes = $__attributesOriginal4bf40cb3dea8912ce01b773d2a33c1e9; ?>
<?php unset($__attributesOriginal4bf40cb3dea8912ce01b773d2a33c1e9); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal4bf40cb3dea8912ce01b773d2a33c1e9)): ?>
<?php $component = $__componentOriginal4bf40cb3dea8912ce01b773d2a33c1e9; ?>
<?php unset($__componentOriginal4bf40cb3dea8912ce01b773d2a33c1e9); ?>
<?php endif; ?>
     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal2094e66eddc217ae20790ec50c8e5484)): ?>
<?php $attributes = $__attributesOriginal2094e66eddc217ae20790ec50c8e5484; ?>
<?php unset($__attributesOriginal2094e66eddc217ae20790ec50c8e5484); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal2094e66eddc217ae20790ec50c8e5484)): ?>
<?php $component = $__componentOriginal2094e66eddc217ae20790ec50c8e5484; ?>
<?php unset($__componentOriginal2094e66eddc217ae20790ec50c8e5484); ?>
<?php endif; ?>

    <form class="d-inline" id="form-delete-record" method="DELETE" action="#"></form>

    <?php if (! $__env->hasRenderedOnce('ebe5e815-63f1-4e27-9cdc-853cebc6cb3a')): $__env->markAsRenderedOnce('ebe5e815-63f1-4e27-9cdc-853cebc6cb3a');
$__env->startPush('scripts'); ?>
        <?php echo e($dataTable->scripts(attributes: ['type' => 'module', 'nonce' => app('csp-nonce')])); ?>

    <?php $__env->stopPush(); endif; ?>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal3f85bed92228172e5e5ea6432b25d994)): ?>
<?php $attributes = $__attributesOriginal3f85bed92228172e5e5ea6432b25d994; ?>
<?php unset($__attributesOriginal3f85bed92228172e5e5ea6432b25d994); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal3f85bed92228172e5e5ea6432b25d994)): ?>
<?php $component = $__componentOriginal3f85bed92228172e5e5ea6432b25d994; ?>
<?php unset($__componentOriginal3f85bed92228172e5e5ea6432b25d994); ?>
<?php endif; ?>
<?php /**PATH D:\laravel\laravel-pemira-hmsi\resources\views/dashboard/voters/index.blade.php ENDPATH**/ ?>