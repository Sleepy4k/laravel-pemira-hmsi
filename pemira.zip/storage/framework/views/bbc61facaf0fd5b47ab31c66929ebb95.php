<?php if (isset($component)) { $__componentOriginal3f85bed92228172e5e5ea6432b25d994 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal3f85bed92228172e5e5ea6432b25d994 = $attributes; } ?>
<?php $component = App\View\Components\Layout\Dashboard::resolve(['title' => 'Candidates'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('layout.dashboard'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\Layout\Dashboard::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <?php if (! $__env->hasRenderedOnce('2d2b3307-d09c-4353-b86d-c795e32391b3')): $__env->markAsRenderedOnce('2d2b3307-d09c-4353-b86d-c795e32391b3');
$__env->startPush('vites'); ?>
        <?php echo app('Illuminate\Foundation\Vite')(['resources/css/lib/datatable.css', 'resources/js/lib/datatable.js', 'resources/js/handler/offcanvas.js', 'resources/js/addon/candidate-page.js']); ?>
    <?php $__env->stopPush(); endif; ?>

    <header data-debug="<?php echo e(config('app.debug') ? 'true' : 'false'); ?>"
        data-routes='{
            "destroy": "<?php echo e(route('dashboard.candidates.destroy', ':id')); ?>"
        }'></header>

    <div class="mb-8 flex items-center justify-between">
        <h1 class="text-3xl font-bold text-neutral-900">
            List of Candidates
        </h1>
        <a href="<?php echo e(route('dashboard.candidates.create')); ?>"
            class="inline-flex items-center gap-2 bg-primary-600 text-white px-4 py-2 rounded-lg font-medium hover:bg-primary-700 transition-colors cursor-pointer">
            <svg xmlns="http://www.w3.org/2000/svg" class="h-5 w-5" viewBox="0 0 20 20" fill="currentColor">
                <path fill-rule="evenodd"
                    d="M10 3a1 1 0 011 1v5h5a1 1 0 110 2h-5v5a1 1 0 11-2 0v-5H4a1 1 0 110-2h5V4a1 1 0 011-1z"
                    clip-rule="evenodd" />
            </svg>
            Candidate
        </a>
    </div>

    <?php echo e($dataTable->table()); ?>


    <form class="d-inline" id="form-delete-record" method="DELETE" action="#"></form>

    <?php if (! $__env->hasRenderedOnce('a8717bb7-ec1e-4972-be22-97d5089426af')): $__env->markAsRenderedOnce('a8717bb7-ec1e-4972-be22-97d5089426af');
$__env->startPush('scripts'); ?>
        <?php echo e($dataTable->scripts(attributes: ['type' => 'module', 'nonce' => app('csp-nonce')])); ?>

    <?php $__env->stopPush(); endif; ?>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal3f85bed92228172e5e5ea6432b25d994)): ?>
<?php $attributes = $__attributesOriginal3f85bed92228172e5e5ea6432b25d994; ?>
<?php unset($__attributesOriginal3f85bed92228172e5e5ea6432b25d994); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal3f85bed92228172e5e5ea6432b25d994)): ?>
<?php $component = $__componentOriginal3f85bed92228172e5e5ea6432b25d994; ?>
<?php unset($__componentOriginal3f85bed92228172e5e5ea6432b25d994); ?>
<?php endif; ?>
<?php /**PATH D:\laravel\laravel-pemira-hmsi\resources\views/dashboard/candidates/index.blade.php ENDPATH**/ ?>