<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
    <head>
        <meta charset="UTF-8">
        <meta name="title" content="<?php echo e($appSettings['app_name']); ?> - <?php echo e($title); ?>">
        <meta name="description" content="<?php echo e($appSettings['app_description']); ?>">
        <meta name="author" content="<?php echo e($appSettings['seo_author']); ?>">
        <meta name="coverage" content="Worldwide">
        <meta name="distribution" content="Global">
        <meta name="robots" content="noindex, nofollow">
        <meta name="keywords" content="<?php echo e($appSettings['seo_keywords']); ?>">
        <meta name="viewport" content="width=device-width, initial-scale=1">

        <link rel="canonical" href="<?php echo e(config('app.url')); ?>">

        <link rel="icon" href="<?php echo e($appSettings['app_favicon']); ?>" />
        <link rel="shortcut icon" href="<?php echo e($appSettings['app_favicon']); ?>" />
        <link rel="apple-touch-icon" href="<?php echo e($appSettings['app_favicon']); ?>" />
        <link rel="apple-touch-icon-precomposed" href="<?php echo e($appSettings['app_favicon']); ?>" />

        <title><?php echo e($appSettings['app_name']); ?> - <?php echo e($title); ?></title>

        <?php echo \Spatie\Csp\CspMetaTag::create() ?>

        <meta property="csp-nonce" content="<?php echo e(app('csp-nonce')); ?>">

        <meta property="og:locale" content="<?php echo e(app()->getLocale()); ?>">
        <meta property="og:url" content="<?php echo e(url()->current()); ?>">
        <meta property="og:type" content="website">
        <meta property="og:site_name" content="<?php echo e($appSettings['app_name']); ?>">
        <meta property="og:title" content="<?php echo e($appSettings['app_name']); ?> - <?php echo e($title); ?>">
        <meta property="og:description" content="<?php echo e($appSettings['app_description']); ?>">
        <meta property="og:image" content="<?php echo e($appSettings['app_logo']); ?>">
        <meta property="og:image:width" content="<?php echo e($appSettings['seo_image_width']); ?>" />
        <meta property="og:image:height" content="<?php echo e($appSettings['seo_image_height']); ?>" />
        <meta property="og:image:type" content="image/png">
        <meta property="og:image:alt" content="<?php echo e($appSettings['app_name']); ?> - <?php echo e($title); ?>">

        <meta property="twitter:card" content="summary_large_image">
        <meta property="twitter:domain" content="<?php echo e(url()->current()); ?>">
        <meta property="twitter:url" content="<?php echo e(url()->current()); ?>">
        <meta property="twitter:locale" content="<?php echo e(app()->getLocale()); ?>">
        <meta property="twitter:title" content="<?php echo e($appSettings['app_name']); ?> - <?php echo e($title); ?>">
        <meta property="twitter:description" content="<?php echo e($appSettings['app_description']); ?>">
        <meta property="twitter:image" content="<?php echo e($appSettings['app_logo']); ?>">
        <meta property="twitter:image:width" content="<?php echo e($appSettings['seo_image_width']); ?>" />
        <meta property="twitter:image:height" content="<?php echo e($appSettings['seo_image_height']); ?>" />
        <meta property="twitter:image:type" content="image/png">
        <meta property="twitter:image:alt" content="<?php echo e($appSettings['app_name']); ?> - <?php echo e($title); ?>">

        <?php echo app('Illuminate\Foundation\Vite')(['resources/css/app.css', 'resources/js/app.js', 'resources/js/addon/layout-error.js']); ?>
    </head>
    <body>
        <main class="min-h-screen flex items-center justify-center bg-gradient-to-br from-cyan-100 via-cyan-200 to-teal-400 p-6">
            <section class="w-full max-w-4xl bg-white/80 backdrop-blur-sm rounded-2xl shadow-xl ring-1 ring-white/30 overflow-hidden">
                <div class="md:flex">
                    <div class="md:w-1/2 p-8 flex flex-col items-start justify-center gap-4">
                        <div class="flex items-center gap-4">
                            <div class="w-16 h-16 flex items-center justify-center rounded-full bg-cyan-50 text-cyan-700 ring-1 ring-cyan-100">
                                <svg class="w-8 h-8" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">
                                    <path d="M3 12a9 9 0 1018 0 9 9 0 00-18 0z"></path>
                                    <path d="M12 8v4"></path>
                                    <path d="M12 16h.01"></path>
                                </svg>
                            </div>
                            <div>
                                <p class="text-sm font-medium text-teal-700">Status</p>
                                <h1 class="text-5xl md:text-6xl font-extrabold tracking-tight text-teal-800"><?php echo e($status); ?></h1>
                            </div>
                        </div>

                        <div class="pt-2">
                            <h2 class="text-2xl font-semibold text-teal-900"><?php echo e($title); ?></h2>
                            <p class="mt-2 text-sm text-teal-800/90"><?php echo e($message); ?></p>
                        </div>

                        <div class="mt-3 flex flex-wrap gap-3">
                            <button id="back-btn" data-href="<?php echo e(url()->previous()); ?>" class="inline-flex items-center px-4 py-2 bg-teal-600 text-white rounded-md shadow-sm hover:bg-teal-700 transition cursor-pointer" style="display: none;">
                                ← Back
                            </button>

                            <button id="home-btn" data-href="<?php echo e(route('landing')); ?>" class="inline-flex items-center px-4 py-2 border border-teal-600 text-teal-700 rounded-md bg-white hover:bg-teal-50 transition cursor-pointer">
                                Home
                            </button>

                            <button id="retry-btn" class="inline-flex items-center px-4 py-2 bg-cyan-50 text-cyan-800 border border-cyan-300 rounded-md hover:bg-cyan-100 transition cursor-pointer">
                                Retry
                            </button>
                        </div>

                        <p class="mt-3 text-xs text-teal-700/60">Timestamp: <span id="timestamp"><?php echo e(now()->toDateTimeString()); ?></span></p>
                    </div>

                    <div class="md:w-1/2 hidden md:flex items-center justify-center bg-gradient-to-br from-teal-600 to-cyan-400 text-white p-8">
                        <div class="text-center max-w-xs">
                            <svg class="mx-auto w-24 h-24 mb-4 opacity-90" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">
                                <path d="M12 2v6"></path>
                                <path d="M12 22v-6"></path>
                                <path d="M4.9 4.9l4.2 4.2"></path>
                                <path d="M19.1 19.1l-4.2-4.2"></path>
                                <path d="M4 12h6"></path>
                                <path d="M14 12h6"></path>
                            </svg>

                            <h3 class="text-2xl font-semibold">It's seems you've encountered an issue.</h3>
                            <p class="mt-2 text-sm opacity-90">If this keeps happening, please report the issue so we can investigate.</p>
                        </div>
                    </div>
                </div>
            </section>
        </main>

        <?php if (isset($component)) { $__componentOriginalaf4532e536ab6e4dc2caf25dfd2e7a59 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalaf4532e536ab6e4dc2caf25dfd2e7a59 = $attributes; } ?>
<?php $component = App\View\Components\Utils\Noscript::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('utils.noscript'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\Utils\Noscript::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalaf4532e536ab6e4dc2caf25dfd2e7a59)): ?>
<?php $attributes = $__attributesOriginalaf4532e536ab6e4dc2caf25dfd2e7a59; ?>
<?php unset($__attributesOriginalaf4532e536ab6e4dc2caf25dfd2e7a59); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalaf4532e536ab6e4dc2caf25dfd2e7a59)): ?>
<?php $component = $__componentOriginalaf4532e536ab6e4dc2caf25dfd2e7a59; ?>
<?php unset($__componentOriginalaf4532e536ab6e4dc2caf25dfd2e7a59); ?>
<?php endif; ?>
    </body>
</html>
<?php /**PATH D:\laravel\laravel-pemira-hmsi\resources\views/components/layout/error.blade.php ENDPATH**/ ?>