<footer class="bg-white border-t border-neutral-200 px-4 lg:px-8 py-4 mt-auto">
    <div class="flex flex-col sm:flex-row items-center justify-between text-sm text-neutral-600">
        <div class="mb-2 sm:mb-0">
            &copy; <?php echo e(date('Y')); ?> <span class="font-semibold text-neutral-700"><?php echo e($appName); ?></span>. All
            rights reserved.
        </div>

        <div class="flex items-center gap-3">
            <span class="text-xs text-neutral-500 hidden sm:inline">Powered by</span>
            <?php $__currentLoopData = $poweredBy; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <a href="<?php echo e($item['url']); ?>" target="_blank" rel="noopener noreferrer"
                    class="transition-transform hover:scale-110 duration-200" title="<?php echo e($item['name']); ?>">
                    <img src="<?php echo e($item['logo']); ?>" alt="<?php echo e($item['name']); ?>" width="24" height="24"
                        class="inline-block" loading="lazy" />
                </a>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
</footer>
<?php /**PATH D:\laravel\laravel-pemira-hmsi\resources\views/components/dashboard/footer.blade.php ENDPATH**/ ?>