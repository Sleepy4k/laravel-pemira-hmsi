<?php if (isset($component)) { $__componentOriginal73ed4a83482684e638654fd752f86427 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal73ed4a83482684e638654fd752f86427 = $attributes; } ?>
<?php $component = App\View\Components\Layout\Landing::resolve(['title' => 'Kandidat '.e(date('Y')).''] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('layout.landing'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\Layout\Landing::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <?php if (! $__env->hasRenderedOnce('eff64828-1e21-4066-976c-a708c56f3b29')): $__env->markAsRenderedOnce('eff64828-1e21-4066-976c-a708c56f3b29');
$__env->startPush('vites'); ?>
        <?php echo app('Illuminate\Foundation\Vite')(['resources/js/lib/boxicons.js', 'resources/css/addon/candidate.css', 'resources/js/addon/candidate-landing-page.js']); ?>
    <?php $__env->stopPush(); endif; ?>

    <div class="container">
        <div class="section-title">
            <h2>Kandidat Pasangan Calon</h2>
            <p>Pilih kandidat terbaik untuk masa depan yang lebih baik</p>
        </div>

        <?php $__empty_1 = true; $__currentLoopData = $candidates; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $candidate): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <div class="candidate-card">
                <div class="card-content">
                    <div class="photo-section">
                        <div class="photo-wrapper">
                            <div class="candidate-number"><?php echo e($candidate->number); ?></div>
                            <img src="<?php echo e($candidate->photo); ?>" alt="Kandidat <?php echo e($candidate->number); ?>">
                        </div>
                        <div class="candidate-name">
                            <h3><?php echo e($candidate->name); ?></h3>
                            <p>Ketua & Wakil Ketua</p>
                        </div>
                    </div>

                    <div class="info-section">
                        <div class="sub-section">
                            <h4><box-icon name='bullseye' color='#16a085'></box-icon> Visi</h4>
                            <p class="vision-text">
                                <?php echo e(Str::limit($candidate->vision->vision, 130, '...')); ?>

                            </p>
                        </div>
                        <div>
                            <h4><box-icon name='bullseye' color='#16a085'></box-icon> Misi</h4>
                            <ul class="info-list">
                                <?php $__currentLoopData = $candidate->missions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $mission): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li>
                                        <span class="number"><?php echo e($index + 1); ?></span>
                                        <span><?php echo e($mission->point); ?></span>
                                    </li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                        </div>
                    </div>

                    <div class="info-section">
                        <h4><box-icon name='clipboard' color='#16a085'></box-icon> Program Kerja</h4>
                        <ul class="info-list">
                            <?php $__currentLoopData = $candidate->programs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $program): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li>
                                    <span class="number"><?php echo e($index + 1); ?></span>
                                    <span><?php echo e($program->point); ?></span>
                                </li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                    </div>

                    <div class="button-section">
                        <button class="btn btn-pdf" id="download-resume-<?php echo e($candidate->number); ?>"
                            data-url="<?php echo e($candidate->resume); ?>">
                            <box-icon name='file-pdf' type='solid' color='#16a085'></box-icon>
                            <span>Download CV</span>
                        </button>
                        <button class="btn btn-visimisi" id="download-attachment-<?php echo e($candidate->number); ?>"
                            data-url="<?php echo e($candidate->attachment); ?>">
                            <box-icon name='file-pdf' type='solid' color='#16a085'></box-icon>
                            <span>Visi Misi & Proker</span>
                        </button>
                    </div>
                </div>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <div class="empty-state">
                <div class="empty-card">
                    <div class="empty-illustration" aria-hidden="true">
                        <svg width="220" height="140" viewBox="0 0 220 140" fill="none"
                            xmlns="http://www.w3.org/2000/svg">
                            <rect x="4" y="10" width="212" height="120" rx="12" fill="#16a085" />
                            <g opacity="1" transform="translate(18,18)">
                                <circle cx="36" cy="36" r="28" fill="#E8F8F5" />
                                <path d="M64 28c0 12-10 22-22 22s-22-10-22-22 10-22 22-22 22 10 22 22z"
                                    fill="#16a085" />
                                <rect x="84" y="10" width="88" height="14" rx="6" fill="#E6F7F2" />
                                <rect x="84" y="34" width="62" height="10" rx="5" fill="#F0FAF8" />
                                <rect x="84" y="52" width="88" height="10" rx="5" fill="#F0FAF8" />
                                <rect x="84" y="74" width="52" height="10" rx="5" fill="#F0FAF8" />
                            </g>
                        </svg>
                    </div>

                    <h3 class="empty-title">Belum ada kandidat</h3>
                    <p class="empty-text">
                        Saat ini belum tersedia pasangan calon. Silakan muat ulang halaman atau kembali ke beranda.
                        Jika Anda menduga ada kesalahan, laporkan ke panitia.
                    </p>

                    <div class="empty-actions">
                        <button class="btn btn-primary" id="reload-page-btn" type="button"
                            aria-label="Muat ulang halaman">
                            Muat Ulang
                        </button>

                        <a href="<?php echo e(url('/')); ?>" class="btn btn-secondary" role="button"
                            aria-label="Kembali ke beranda">
                            Kembali ke Beranda
                        </a>

                        <a href="https://www.instagram.com/pemirahmsi.tup" class="btn btn-outline" role="button"
                            aria-label="Laporkan ke panitia" target="_blank" rel="noopener">
                            Laporkan ke Panitia
                        </a>
                    </div>
                </div>
            </div>
        <?php endif; ?>
    </div>

    <div id="pdf-modal" class="pdf-modal">
        <div class="pdf-modal-content" id="pdf-modal-content"></div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal73ed4a83482684e638654fd752f86427)): ?>
<?php $attributes = $__attributesOriginal73ed4a83482684e638654fd752f86427; ?>
<?php unset($__attributesOriginal73ed4a83482684e638654fd752f86427); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal73ed4a83482684e638654fd752f86427)): ?>
<?php $component = $__componentOriginal73ed4a83482684e638654fd752f86427; ?>
<?php unset($__componentOriginal73ed4a83482684e638654fd752f86427); ?>
<?php endif; ?>
<?php /**PATH D:\laravel\laravel-pemira-hmsi\resources\views/landing/candidate.blade.php ENDPATH**/ ?>