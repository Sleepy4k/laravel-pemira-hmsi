<?php if (isset($component)) { $__componentOriginal3f85bed92228172e5e5ea6432b25d994 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal3f85bed92228172e5e5ea6432b25d994 = $attributes; } ?>
<?php $component = App\View\Components\Layout\Dashboard::resolve(['title' => 'Voting'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('layout.dashboard'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\Layout\Dashboard::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <?php if (! $__env->hasRenderedOnce('24ff5f7b-17f5-4469-bf67-b8b3584ee9cc')): $__env->markAsRenderedOnce('24ff5f7b-17f5-4469-bf67-b8b3584ee9cc');
$__env->startPush('vites'); ?>
        <?php echo app('Illuminate\Foundation\Vite')(['resources/js/addon/voting-page.js']); ?>
    <?php $__env->stopPush(); endif; ?>

    <header data-success="<?php echo e(session('success', '')); ?>" data-error="<?php echo e(session('error', '')); ?>"></header>

    <div class="mb-8 flex items-center justify-between">
        <h1 class="text-3xl font-bold text-neutral-900">
            Voting
        </h1>
    </div>

    <div class="mb-6 border-b border-gray-200">
        <nav class="-mb-px flex space-x-8" aria-label="Tabs">
            <?php $__currentLoopData = $settingsTabs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tabKey => $tabLabel): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <a href="<?php echo e(route('dashboard.voting.index', ['tab' => $tabKey])); ?>"
                    class="whitespace-nowrap py-4 px-1 border-b-2 font-medium text-sm <?php echo e($activeTab === $tabKey ? 'border-primary-500 text-primary-600' : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'); ?>">
                    <?php echo e($tabLabel); ?>

                </a>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </nav>
    </div>

    <div id="voting-settings" style="<?php echo e($activeTab === 'voting' ? '' : 'display: none;'); ?>">
        <div class="p-6 bg-white rounded-xl shadow-sm">
            <h2 class="font-semibold text-gray-900 mb-4">Voting Settings</h2>
            <form method="POST"
                action="<?php echo e(route('dashboard.voting.update', ['tab' => 'voting', 'voting' => $types['voting']])); ?>">
                <?php echo csrf_field(); ?>
                <?php echo method_field('PUT'); ?>

                <div class="mb-4 flex flex-col md:flex-row md:space-x-6">
                    <div class="md:w-1/2">
                        <label for="voting_start" class="block text-sm font-medium text-gray-700">Voting Start
                            Date</label>
                        <input type="datetime-local" name="voting_start" id="voting_start"
                            value="<?php echo e(old('voting_start', $settings['voting_start'] ?? '')); ?>"
                            class="mt-1 block w-full border border-gray-300 rounded-md shadow-sm p-2 focus:ring-primary-500 focus:border-primary-500 sm:text-sm">
                    </div>

                    <div class="md:w-1/2 mt-4 md:mt-0">
                        <label for="voting_end" class="block text-sm font-medium text-gray-700">Voting End Date</label>
                        <input type="datetime-local" name="voting_end" id="voting_end"
                            value="<?php echo e(old('voting_end', $settings['voting_end'] ?? '')); ?>"
                            class="mt-1 block w-full border border-gray-300 rounded-md shadow-sm p-2 focus:ring-primary-500 focus:border-primary-500 sm:text-sm">
                    </div>
                </div>

                <div class="mt-2 flex justify-end">
                    <button type="submit"
                        class="inline-flex items-center gap-2 bg-primary-600 text-white px-4 py-2 rounded-lg font-medium hover:bg-primary-700 transition-colors cursor-pointer">
                        Save Settings
                    </button>
                </div>
            </form>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal3f85bed92228172e5e5ea6432b25d994)): ?>
<?php $attributes = $__attributesOriginal3f85bed92228172e5e5ea6432b25d994; ?>
<?php unset($__attributesOriginal3f85bed92228172e5e5ea6432b25d994); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal3f85bed92228172e5e5ea6432b25d994)): ?>
<?php $component = $__componentOriginal3f85bed92228172e5e5ea6432b25d994; ?>
<?php unset($__componentOriginal3f85bed92228172e5e5ea6432b25d994); ?>
<?php endif; ?>
<?php /**PATH D:\laravel\laravel-pemira-hmsi\resources\views/dashboard/settings/voting.blade.php ENDPATH**/ ?>