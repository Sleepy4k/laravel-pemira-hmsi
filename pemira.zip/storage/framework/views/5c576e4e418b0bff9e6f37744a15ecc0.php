<aside id="sidebar"
    class="w-64 flex-shrink-0 bg-white shadow-lg fixed lg:static inset-y-0 left-0 z-40 transform -translate-x-full lg:translate-x-0 transition-transform duration-300 overflow-y-auto lg:overflow-y-visible">
    <div class="h-full flex flex-col">
        <a href="<?php echo e(route('landing')); ?>"
            class="px-4 lg:px-6 py-3 flex items-center justify-center border-b border-neutral-200 sticky top-0 bg-white z-10">
            <img src="<?php echo e($appLogo); ?>" alt="Logo" loading="lazy" class="w-10 h-12" />
            <div class='m-1'></div>
            <span class="text-xl font-bold text-primary-500"><?php echo e($appName); ?></span>
        </a>

        <nav class="flex-1 space-y-2 p-4">
            <div class="text-center text-neutral-500 py-4" id="loader">Loading...</div>
            <?php $__currentLoopData = $menus; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $menu): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php if($menu['is_header']): ?>
                    <div id="sidebar-link" style="display: none;">
                        <h3 class="mt-6 mb-2 px-3 text-xs font-semibold text-neutral-400 uppercase tracking-wider">
                            <?php echo e($menu['name']); ?>

                        </h3>
                    </div>
                <?php else: ?>
                    <a href="<?php echo e(route($menu['route'])); ?>" id="sidebar-link" style="display: none;"
                        class="flex items-center space-x-3 rounded-lg p-3 text-body-lg font-semibold transition-colors <?php echo e($currentUrl === route($menu['route']) ? $activeClasses : $inactiveClasses); ?>">
                        <box-icon name="<?php echo e($menu['icon']); ?>"></box-icon>
                        <span><?php echo e($menu['name']); ?></span>
                    </a>
                <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </nav>
    </div>
</aside>
<?php /**PATH D:\laravel\laravel-pemira-hmsi\resources\views/components/dashboard/sidebar.blade.php ENDPATH**/ ?>