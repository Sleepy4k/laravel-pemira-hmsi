document.addEventListener("DOMContentLoaded",function(){const l=document.getElementById("update-candidate-form");l&&l.addEventListener("submit",function(s){s.preventDefault();const d=l.dataset.action||l.getAttribute("action"),u=l.dataset.method||l.getAttribute("method")||"PUT",o=l.dataset.redirect||l.getAttribute("data-redirect")||null,m=new FormData(l);l.querySelectorAll('input[type="file"]').forEach(e=>{e.files.length===0&&m.delete(e.name)}),axios({method:u,url:d,data:m,headers:{"Content-Type":"multipart/form-data",Accept:"application/json"}}).then(e=>{typeof window.Toast<"u"?window.Toast.fire({icon:"success",title:"Candidate updated successfully!"}):alert("Candidate updated successfully!"),o&&(window.location.href=o)}).catch(e=>{let i="An error occurred while submitting the form.";e.response&&e.response.data&&e.response.data.message&&(i=e.response.data.message),typeof window.Toast<"u"?window.Toast.fire({icon:"error",title:i}):alert(i)})});const E=(s="")=>String(s).replace(/[&<>"']/g,d=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"})[d]);function y({name:s,max:d,previewId:u,containerId:o,addBtnId:m,inputSelectors:f=[]}){const e=document.getElementById(u),i=document.getElementById(o),a=document.getElementById(m);let n=null;if(i){for(const r of f){const t=i.querySelector(r);if(t){n=t;break}}n||(n=i.querySelector('input[type="text"], input[type="search"], input[type="search"]'))}if(!n)for(const r of f){const t=document.querySelector(r);if(t){n=t;break}}if(!e)return null;const p=`${s}-item`,L=`delete-${s}-btn`,g=()=>{const r=e.querySelectorAll(`.${p}`).length;if(a){const t=r>=d;a.disabled=t,a.classList.toggle("opacity-50",t),a.classList.toggle("cursor-not-allowed",t)}},$=r=>{const t=E(r),c=document.createElement("div");return c.className=`${p} mb-2`,c.innerHTML=`
                    <div class="flex items-center w-full">
                        <span class="w-9/10 px-4 py-2.5 border border-gray-200 rounded-lg text-gray-700 bg-gray-100 break-words" title="${t}">
                            ${t}
                        </span>
                        <input type="hidden" name="${s}[]" value="${t}">
                        <button type="button" class="${L} ml-3 w-1/10 bg-primary-600 hover:bg-primary-700 text-white p-2 rounded-lg cursor-pointer shadow-md flex items-center justify-center">
                            <box-icon name="trash" color="#ff0000ff"></box-icon>
                        </button>
                    </div>
                `,c};return e.addEventListener("click",r=>{const t=r.target.closest&&r.target.closest(`.${L}`);if(!t)return;const c=t.closest(`.${p}`);c&&(c.remove(),g())}),a&&a.addEventListener("click",r=>{r.preventDefault();const t=n?n.value.trim():"";if(!t){n&&(n.classList.add("border-red-500"),n.focus(),setTimeout(()=>n.classList.remove("border-red-500"),800));return}if(e.querySelectorAll(`.${p}`).length>=d)return;const v=$(t);e.appendChild(v),n&&(n.value="",n.focus()),g()}),n&&n.addEventListener("keydown",r=>{r.key==="Enter"&&(r.preventDefault(),a&&a.click())}),(function(){if(e.querySelectorAll(`.${p}`).length>0){g();return}const t=document.querySelectorAll(`input[name="${s}[]"]`);for(const c of t){if(!c.value||!c.value.trim())continue;if(e.querySelectorAll(`.${p}`).length>=d)break;const v=$(c.value.trim());e.appendChild(v),c.remove()}g()})(),{refresh:g}}y({name:"missions",max:3,previewId:"missions-preview",containerId:"missions-input-container",addBtnId:"add-mission-btn",inputSelectors:['input[data-role="mission-input"]','input[name="mission"]',"#mission","#mission-input"]}),y({name:"programs",max:5,previewId:"programs-preview",containerId:"programs-input-container",addBtnId:"add-program-btn",inputSelectors:['input[data-role="program-input"]','input[name="program"]',"#program","#program-input"]});const h=document.getElementById("photo"),b=document.getElementById("photo-preview-container"),w=document.getElementById("photo-preview");h&&h.addEventListener("change",function(){const s=this.files[0];if(s){const d=new FileReader;d.onload=function(u){w.src=u.target.result,b.classList.remove("hidden")},d.readAsDataURL(s)}else w.src="#",b.classList.add("hidden")});const x=(s,d)=>{const u=document.getElementById(s),o=document.getElementById(d);if(!u||!o)return;const m=()=>{if(o.dataset.url){try{URL.revokeObjectURL(o.dataset.url)}catch{}delete o.dataset.url}},f=(e,i)=>{const a=(e.size/1024).toFixed(1),n=e.type||e.name&&e.name.split(".").pop()||"file";return`
                    <div class="flex items-center justify-between p-3 border rounded-md bg-gray-50">
                        <div class="flex items-center space-x-3 min-w-0">
                            <div class="min-w-0">
                                <a href="${i}" target="_blank" rel="noopener noreferrer" class="block text-sm font-medium text-blue-600 underline truncate" title="${e.name}">
                                    ${e.name}
                                </a>
                                <div class="text-xs text-gray-500">
                                    ${a} KB • ${n}
                                </div>
                            </div>
                        </div>
                        <div class="flex items-center space-x-2">
                            <a href="${i}" download class="text-sm px-2 py-1 rounded text-gray-700 hover:bg-gray-50">
                                <box-icon name="cloud-download" type="solid"></box-icon>
                            </a>
                            <button type="button" class="remove-file-btn text-sm px-2 py-1 text-red-600 hover:bg-red-50 rounded cursor-pointer">
                                <box-icon name="trash" type="solid"></box-icon>
                            </button>
                        </div>
                    </div>
                `};u.addEventListener("change",function(){const e=this.files&&this.files[0];if(!e){m(),o.innerHTML="",o.classList.add("hidden"),u.value="";return}m();const i=URL.createObjectURL(e);o.dataset.url=i,o.innerHTML=f(e,i),o.classList.remove("hidden");const a=o.querySelector(".remove-file-btn");a&&a.addEventListener("click",function(){u.value="",m(),o.innerHTML="",o.classList.add("hidden")},{once:!0})})};x("resume","resume-preview-container"),x("attachment","attachment-preview-container")});
