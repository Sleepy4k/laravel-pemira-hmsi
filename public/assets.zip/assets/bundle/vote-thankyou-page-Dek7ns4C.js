document.addEventListener("DOMContentLoaded",function(){const o=document.querySelector("header"),a=new Date(o.getAttribute("data-end-time")).getTime(),n=document.getElementById("countdownTimer");function e(){const r=new Date().getTime(),t=a-r;if(t<0){n.innerHTML="Waktu voting telah berakhir.",clearInterval(d);return}const s=Math.floor(t%(1e3*60*60*24)/(1e3*60*60)),i=Math.floor(t%(1e3*60*60)/(1e3*60)),c=Math.floor(t%(1e3*60)/1e3);n.innerHTML=`
            <span id="days">${String(Math.floor(t/(1e3*60*60*24))).padStart(2,"0")}</span>d :
            <span id="hours">${String(s).padStart(2,"0")}</span>h :
            <span id="minutes">${String(i).padStart(2,"0")}</span>m :
            <span id="seconds">${String(c).padStart(2,"0")}</span>s
        `}e();const d=setInterval(e,1e3)});
