document.addEventListener("DOMContentLoaded",function(){let c=0;const p=document.querySelector("header[data-current-date]"),r=new Date(p.getAttribute("data-current-date")+"T00:00:00"),d=document.querySelectorAll(".timeline-item");if(d.forEach(e=>{const u=e.getAttribute("data-start"),m=e.getAttribute("data-end");if(!u||!m)return;const y=new Date(u),S=new Date(m),g=e.querySelector(".timeline-badge"),s=e.querySelector(".timeline-content");if(r<y)e.classList.add("upcoming");else if(r>S){e.classList.add("completed"),c++;const n=s.querySelector(".status-indicator");n&&n.remove()}else{if(e.classList.add("active"),!s.querySelector(".status-indicator")){const t=document.createElement("div");t.className="status-indicator",t.innerHTML='<span class="status-dot"></span>Sedang Berlangsung',s.appendChild(t)}g.classList.contains("active-badge")||g.classList.add("active-badge");const n=e.querySelector(".timeline-dot");if(!n.querySelector(".pulse-ring")){const t=document.createElement("span");t.className="pulse-ring",n.appendChild(t)}}}),!document.querySelector(".timeline"))return;const a=document.createElement("style"),o="timeline-gradient-style";document.head.querySelector("#"+o)&&document.head.querySelector("#"+o).remove(),a.id=o;const i=document.head.querySelector('meta[property="csp-nonce"]');i&&a.setAttribute("nonce",i.content);const l=c>=0?c/d.length*100:0;a.innerHTML=`
        .timeline::before {
            background: linear-gradient(180deg,
                #1abc9c 0%,
                #1abc9c ${l+2}%,
                #e0e0e0 ${l+2}%,
                #e0e0e0 100%) !important;
        }
    `,document.head.appendChild(a)});
