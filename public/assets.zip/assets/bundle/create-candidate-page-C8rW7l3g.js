document.addEventListener("DOMContentLoaded",function(){const u=document.getElementById("create-candidate-form");u&&u.addEventListener("submit",function(s){s.preventDefault();const a=u.dataset.action||u.getAttribute("action"),d=u.dataset.method||u.getAttribute("method")||"POST",o=u.dataset.redirect||u.getAttribute("data-redirect")||null,p=new FormData(u);axios({method:d,url:a,data:p,headers:{"Content-Type":"multipart/form-data",Accept:"application/json"}}).then(l=>{typeof window.Toast<"u"?window.Toast.fire({icon:"success",title:"Candidate created successfully!"}):alert("Candidate created successfully!"),o&&(window.location.href=o)}).catch(l=>{let e="An error occurred while submitting the form.";l.response&&l.response.data&&l.response.data.message&&(e=l.response.data.message),typeof window.Toast<"u"?window.Toast.fire({icon:"error",title:e}):alert(e)})});const E=(s="")=>String(s).replace(/[&<>"']/g,a=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"})[a]);function y({name:s,max:a,previewId:d,containerId:o,addBtnId:p,inputSelectors:l=[]}){const e=document.getElementById(d),m=document.getElementById(o),i=document.getElementById(p);let n=null;if(m){for(const r of l){const t=m.querySelector(r);if(t){n=t;break}}n||(n=m.querySelector('input[type="text"], input[type="search"], input[type="search"]'))}if(!n)for(const r of l){const t=document.querySelector(r);if(t){n=t;break}}if(!e)return null;const f=`${s}-item`,L=`delete-${s}-btn`,g=()=>{const r=e.querySelectorAll(`.${f}`).length;if(i){const t=r>=a;i.disabled=t,i.classList.toggle("opacity-50",t),i.classList.toggle("cursor-not-allowed",t)}},$=r=>{const t=E(r),c=document.createElement("div");return c.className=`${f} mb-2`,c.innerHTML=`
                    <div class="flex items-center w-full">
                        <span class="w-9/10 px-4 py-2.5 border border-gray-200 rounded-lg text-gray-700 bg-gray-100 break-words" title="${t}">
                            ${t}
                        </span>
                        <input type="hidden" name="${s}[]" value="${t}">
                        <button type="button" class="${L} ml-3 w-1/10 bg-primary-600 hover:bg-primary-700 text-white p-2 rounded-lg cursor-pointer shadow-md flex items-center justify-center">
                            <box-icon name="trash" color="#ff0000ff"></box-icon>
                        </button>
                    </div>
                `,c};return e.addEventListener("click",r=>{const t=r.target.closest&&r.target.closest(`.${L}`);if(!t)return;const c=t.closest(`.${f}`);c&&(c.remove(),g())}),i&&i.addEventListener("click",r=>{r.preventDefault();const t=n?n.value.trim():"";if(!t){n&&(n.classList.add("border-red-500"),n.focus(),setTimeout(()=>n.classList.remove("border-red-500"),800));return}if(e.querySelectorAll(`.${f}`).length>=a)return;const v=$(t);e.appendChild(v),n&&(n.value="",n.focus()),g()}),n&&n.addEventListener("keydown",r=>{r.key==="Enter"&&(r.preventDefault(),i&&i.click())}),(function(){if(e.querySelectorAll(`.${f}`).length>0){g();return}const t=document.querySelectorAll(`input[name="${s}[]"]`);for(const c of t){if(!c.value||!c.value.trim())continue;if(e.querySelectorAll(`.${f}`).length>=a)break;const v=$(c.value.trim());e.appendChild(v),c.remove()}g()})(),{refresh:g}}y({name:"missions",max:3,previewId:"missions-preview",containerId:"missions-input-container",addBtnId:"add-mission-btn",inputSelectors:['input[data-role="mission-input"]','input[name="mission"]',"#mission","#mission-input"]}),y({name:"programs",max:5,previewId:"programs-preview",containerId:"programs-input-container",addBtnId:"add-program-btn",inputSelectors:['input[data-role="program-input"]','input[name="program"]',"#program","#program-input"]});const h=document.getElementById("photo"),b=document.getElementById("photo-preview-container"),w=document.getElementById("photo-preview");h&&h.addEventListener("change",function(){const s=this.files[0];if(s){const a=new FileReader;a.onload=function(d){w.src=d.target.result,b.classList.remove("hidden")},a.readAsDataURL(s)}else w.src="#",b.classList.add("hidden")});const x=(s,a)=>{const d=document.getElementById(s),o=document.getElementById(a);if(!d||!o)return;const p=()=>{if(o.dataset.url){try{URL.revokeObjectURL(o.dataset.url)}catch{}delete o.dataset.url}},l=(e,m)=>{const i=(e.size/1024).toFixed(1),n=e.type||e.name&&e.name.split(".").pop()||"file";return`
                    <div class="flex items-center justify-between p-3 border rounded-md bg-gray-50">
                        <div class="flex items-center space-x-3 min-w-0">
                            <div class="min-w-0">
                                <a href="${m}" target="_blank" rel="noopener noreferrer" class="block text-sm font-medium text-blue-600 underline truncate" title="${e.name}">
                                    ${e.name}
                                </a>
                                <div class="text-xs text-gray-500">
                                    ${i} KB • ${n}
                                </div>
                            </div>
                        </div>
                        <div class="flex items-center space-x-2">
                            <a href="${m}" download class="text-sm px-2 py-1 rounded text-gray-700 hover:bg-gray-50">
                                <box-icon name="cloud-download" type="solid"></box-icon>
                            </a>
                            <button type="button" class="remove-file-btn text-sm px-2 py-1 text-red-600 hover:bg-red-50 rounded cursor-pointer">
                                <box-icon name="trash" type="solid"></box-icon>
                            </button>
                        </div>
                    </div>
                `};d.addEventListener("change",function(){const e=this.files&&this.files[0];if(!e){p(),o.innerHTML="",o.classList.add("hidden"),d.value="";return}p();const m=URL.createObjectURL(e);o.dataset.url=m,o.innerHTML=l(e,m),o.classList.remove("hidden");const i=o.querySelector(".remove-file-btn");i&&i.addEventListener("click",function(){d.value="",p(),o.innerHTML="",o.classList.add("hidden")},{once:!0})})};x("resume","resume-preview-container"),x("attachment","attachment-preview-container")});
